import sys
from nltk import sent_tokenize
from nltk.sentiment.vader import SentimentIntensityAnalyzer

for line in sys.stdin:

    # First, we take the input line and tokenize it by sentence.
    sent = sent_tokenize(line, 'english')

    # This is what does all the work for the sentiment analysis.
    sid = SentimentIntensityAnalyzer()

    # This is the final result.
    endValue = ""

    # And now, for each sentence in our list of sentences
    for sentence in sent:
        # We ask Sid to get the polarity and put it away for later use.
        ss = sid.polarity_scores(sentence)
        element = ""
        # k is category as a string, ss[k] is the percentage that category is represented in the string 'sentence'
        # Three categories exist for this implementation; negative, neutral, and positive.
        for k in ss:
            # This is where we pull out our results and do things to them. Yay things.
            element = element + "{0} ".format(ss[k])

        print(element)
    print("eoe")
